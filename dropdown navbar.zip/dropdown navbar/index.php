<html>
<head>
    <title>Drop-down Menu Design</title>
    <link rel="stylesheet" href="style.css">
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</head>
    <body>
        <div class="menu-bar">
        <ul>
            <li class="active"><a href="#"><ion-icon class="fa" name="home"></ion-icon>Home</a></li>
            <li><a href="#"><ion-icon class="fa" name="person"></ion-icon>About Us</a>
            <div class="sub-menu-1">
                <ul>
                    <li><a href="About.php">Mission</a></li>
                    <li><a href="#">Vision</a></li>
                    <li><a href="#">Team</a></li>
                </ul>
            </div>
            </li>
            <li><a href="#"><ion-icon class="fa" name="copy-outline"></ion-icon>Service</a>
            <div class="sub-menu-1">
                <ul>
                    <li><a href="#">Web Designing</a></li>
                    <li class="hover-me"><a href="#">Marketing</a><ion-icon class="forward"name="chevron-forward"></ion-icon>
                    <div class="sub-menu-2">
                    <ul>
                        <li><a href="#">SEO</a></li>
                        <li><a href="#">Social Media</a></li>
                        <li><a href="#">Email Marketing</a></li>
                    </ul>
                    </div>
                    </li>
                    <li class="hover-me"><a href="#">Mobile App</a><ion-icon class="forward" name="chevron-forward"></ion-icon>
                    <div class="sub-menu-2">
                    <ul>
                        <li><a href="#">Android App</a></li>
                        <li><a href="#">iOS App</a></li>
                        <li><a href="#">Ionic App</a></li>
                        <li><a href="#">Flutter App</a></li>
                        <li><a href="#">Unity App</a></li>
                    </ul>
                    </li>
                    </div>
                    </li>
                    <li><a href="#"><ion-icon class="fa" name="people-outline"></ion-icon>Clients</a></li>
                    <li><a href="#"><ion-icon class="fa" name="cash-outline"></ion-icon>Investors</a></li>
                    <li><a href="#"><ion-icon class="fa" name="wallet-outline"></ion-icon>Pricing</a></li>
                    <li><a href="#"><ion-icon class="fa" name="barbell-outline"></ion-icon>Training</a></li>
                    <li><a href="#"><ion-icon class="fa" name="call"></ion-icon>Contact</a></li>
                </ul>
        </div> 
    </body>
</html>
